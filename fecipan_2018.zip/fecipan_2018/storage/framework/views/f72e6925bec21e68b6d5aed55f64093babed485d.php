<!--esta visão irá aparecer dentro da principal.blade-->

<?php $__env->startSection('conteudo'); ?>

<h1>Países Cadastrados</h1>
<table class="table table-condensed table-hover table-striped">
	<thead>
		<tr>
			<th>#</th>
			<th>Nome</th>
			<th>Gentílico</th>
			<th>Siglas</th>
			<th>Pessoas</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($pais->id); ?></td>
			<td><?php echo e($pais->nome); ?></td>
			<td><?php echo e($pais->gentilico); ?></td>
			<td><?php echo e($pais->sigla); ?> / <?php echo e($pais->sigla_web); ?></td>
			<td><?php echo e($pais->usuarios->count()); ?></td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>