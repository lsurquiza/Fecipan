<?php $__env->startSection('conteudo'); ?>

<?php if($permissoes->visualizar): ?>
	<h1>
		Quesitos de Avaliação para a
		<?php echo e($evento->titulo); ?> <?php echo e($evento->ano); ?>/<?php echo e($evento->semestre); ?>

	</h1>
	<p>
		<?php echo e($evento->tema); ?>

	</p>
	<hr>
	<div class='text-right'>
	  <a class='btn btn-primary btn-sm' href="/evento">
		Voltar
	  </a>
	</div>
	<?php if($permissoes->inserir == true): ?>
	<a href="\quesito\create\<?php echo e($evento->id); ?>" class="btn btn-primary">
		<span class="glyphicon glyphicon-file"></span>
		Cadastrar Quesito
	</a>
	<?php endif; ?>
	<br><br>

	<table id="table" class="table table-condensed table-hover table-striped">
		<thead>
		  <tr>
			<th>ID</th>
			<th>Enunciado</th>
			<th class="text-right">Peso</th>
			<th>Ações</th>
		  </tr>
		</thead>
		<tbody>
		<?php $__currentLoopData = $evento->quesitos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		  <tr>
			<td><?php echo e($q->id); ?></td>
			<td><?php echo e($q->enunciado); ?></td>
			<td class="text-right"><?php echo e($q->peso); ?></td>
			<td> 
			  <div class='btn-group'>
				  <?php if($permissoes->alterar): ?>
				  <a class='btn btn-primary btn-sm' href="/quesito/update/<?php echo e($q->id); ?>" title="Alterar quesito #<?php echo e($q->id); ?>"> 
					<span class="glyphicon glyphicon-pencil"></span>
				  </a>
				  <?php endif; ?>
				  <?php if($permissoes->excluir): ?>
				  <a class='btn btn-primary btn-sm' href="#" data-toggle="modal" data-target="#<?php echo e($q->id); ?>"title="Excluir quesito #<?php echo e($q->id); ?>">
					<span class="glyphicon glyphicon-trash"></span>
				  </a>
				  <?php endif; ?>
			  </div>
			  <div id="<?php echo e($q->id); ?>" class="modal fade text-justify" role="dialog">
				  <div class="site-wrapper">
					<div class="modal-dialog">                
					  <div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">
								<span class="glyphicon glyphicon-alert"></span>
								Exclusão de Quesito
							</h4>
						  </div>
						  
						  <div class="modal-body">
							<p>Deseja excluir o quesito <strong><?php echo e($q->id); ?> - <?php echo e($q->enunciado); ?></strong>?</p>
						  </div>
						  
						  <div class="modal-footer">
							<a href="/quesito/delete/<?php echo e($q->id); ?>" class="btn btn-danger">Sim</a>
							<button class="btn btn-info" data-dismiss="modal">Não</button>
						</div>
					  </div>
					</div>
				  </div>
			  </div>
			</td>
		  </tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</tbody>
	</table>
<?php endif; ?>
	<div class='text-right'>
	  <a class='btn btn-primary btn-sm' href="/evento">
		Voltar
	  </a>
	</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>