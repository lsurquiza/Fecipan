<!--esta visão irá aparecer dentro da principal.blade-->

<?php $__env->startSection('conteudo'); ?>

<h1>Perfis associados a <?php echo e($usuario->nome); ?> </h1>
<table class="table table-condensed table-hover table-striped">
	<thead>
		<tr>
			<th>#</th>
			<th>Descricao</th>
			<th>Habilitado</th>
			<th>Usual</th>
			<th>Ações</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $usuario->perfisPorUsuario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfil): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($perfil->perfil_id); ?></td>
			<td><?php echo e($perfil->descricao); ?></td>
			<td><?php echo e($perfil->habilitado); ?></td>
			<td><?php echo e($perfil->usual); ?></td>
			<td>
				<div class="btn-group">
				<?php if($perfil->usual == 0): ?>
					<a href="\perfilUsuario\delete\<?php echo e($usuario->id); ?>\<?php echo e($perfil->perfil_id); ?>" class="btn btn-sm btn-primary" title="Desassociar Perfil">
						<span class="glyphicon glyphicon-trash"></span>
					</a>
				<?php endif; ?>
				</div>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>

<a href="\perfilUsuario\create" class="btn btn-primary">
	<span class="glyphicon glyphicon-file"></span>
	Associar Perfis
</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>