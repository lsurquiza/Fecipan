<?php $__env->startSection('conteudo'); ?>
<div class="panel panel-default">
	<div class="panel-heading">
		<h4>
			Cadastrar Trabalho na <?php echo e($evento->titulo); ?>

		</h4>
		<p><?php echo e($evento->tema); ?></p>
	</div>
	<div class="panel-body">
	<form class="form-horizontal" action="/trabalho/create" method="POST">
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
		<input type="hidden" name="evento_id" value="<?php echo e($evento->id); ?>" />
		<fieldset>
	    <div class="form-group">
		  <label class="col-sm-4 col-md-3 control-label" for="categoria_id">Categoria</label>  

		  <div class="col-sm-6 col-md-4">
		  	<select id="categoria_id" name="categoria_id" data-placeholder="Escolha a categoria" class="chosen-select form-control input-md">
				<option value=""></option>
				<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->descricao); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</select>
		  	<?php if(count($errors)>0): ?>
		  	 	<div class="text-danger">			
					<li style="list-style-type:none"><?php echo e($errors->first('categoria_id')); ?></li>
				</div>
			<?php endif; ?>	
		  </div>
		</div>

	    <div class="form-group">
		  <label class="col-sm-4 col-md-3 control-label" for="tipo_trabalho_id">Tipo</label>  

		  <div class="col-sm-8 col-md-6">
		  	<select id="tipo_trabalho_id" name="tipo_trabalho_id" data-placeholder="Escolha o tipo" class="chosen-select form-control input-md">
				<option value=""></option>
				<?php $__currentLoopData = $tiposTrabalho; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoTrabalho): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<option value="<?php echo e($tipoTrabalho->id); ?>"><?php echo e($tipoTrabalho->nome); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</select>
		  	<?php if(count($errors)>0): ?>
		  	 	<div class="text-danger">			
					<li style="list-style-type:none"><?php echo e($errors->first('tipo_trabalho_id')); ?></li>
				</div>
			<?php endif; ?>	
		  </div>
		</div>

		<div class="form-group">
		  <label class="col-sm-4 col-md-3 control-label" for="titulo">Título</label>  
		  
		  <div class="col-sm-8 col-md-6">
			<input type="text" id="titulo" name="titulo" class="form-control input-md" placeholder="Título do Trabalho">
		  </div>
		  	<?php if(count($errors)>0): ?>
		  	 	<div class="text-danger">			
					<li style="list-style-type:none"><?php echo e($errors->first('titulo')); ?></li>
				</div>
			<?php endif; ?>	
		</div>

		<div class="form-group">
			<label class="col-sm-4 col-md-3 control-label" for="area_id">Área</label>  
			<div class="col-sm-8 col-md-6">
		  	<select id="area_id" name="area_id" data-placeholder="Escolha a área" class="chosen-select form-control input-md">
				<option value=""></option>
				<?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<option value="<?php echo e($area->id); ?>"><?php echo e($area->sigla); ?> - <?php echo e($area->area); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</select>
		  	<?php if(count($errors)>0): ?>
		  	 	<div class="text-danger">			
					<li style="list-style-type:none"><?php echo e($errors->first('area_id')); ?></li>
				</div>
			<?php endif; ?>	
		  </div>
		</div>

		<div class="form-group">
		  <label class="col-sm-4 col-md-3 control-label" for="cod">Código</label>  
		  
		  <div class="col-sm-3 col-md-2">
			<input type="text" id="cod" name="cod" class="form-control input-md" placeholder="Título do Trabalho">
		  </div>
		  	<?php if(count($errors)>0): ?>
		  	 	<div class="text-danger">			
					<li style="list-style-type:none"><?php echo e($errors->first('cod')); ?></li>
				</div>
			<?php endif; ?>	
		</div>
		
	    <div class="form-group">
		  <label class="col-sm-4 col-md-3 control-label" for="orientador_id">Orientadores</label>  

		  <div class="col-sm-8 col-md-6">
		  	<select id="orientador" name="orientador_id" data-placeholder="Escolha o Orientador" class="chosen-select form-control input-md">
				<option value=""></option>
				<?php $__currentLoopData = $orientadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orientador): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<option value="<?php echo e($orientador->id); ?>"><?php echo e($orientador->instituicao->sigla); ?> - <?php echo e($orientador->pessoa->nome); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</select>
		  	<?php if(count($errors)>0): ?>
		  	 	<div class="text-danger">			
					<li style="list-style-type:none"><?php echo e($errors->first('orientador_id')); ?></li>
				</div>
			<?php endif; ?>	
		  </div>
		</div>
		
	    <div class="form-group">
		  <label class="col-sm-4 col-md-3 control-label" for="coorientadores">Coorientadores</label>  
		  <div class="col-sm-8 col-md-6">
		  	<select id="coorientadores" name="coorientadores[]" multiple data-placeholder="Escolha os Coorientadores" class="chosen-select form-control input-md">
				<option value=""></option>
				<?php $__currentLoopData = $orientadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orientador): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<option value="<?php echo e($orientador->id); ?>"><?php echo e($orientador->instituicao->sigla); ?> - <?php echo e($orientador->pessoa->nome); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</select>
		  	<?php if(count($errors)>0): ?>
		  	 	<div class="text-danger">			
					<li style="list-style-type:none"><?php echo e($errors->first('orientadores')); ?></li>
				</div>
			<?php endif; ?>	
		  </div>
		</div>

		<div class="form-group">
		  <label class="col-sm-4 col-md-3 control-label" for="estudantes">Estudantes</label>  
		  <div class="col-sm-8 col-md-6">
		  	<select id="estudantes" name="estudantes[]" multiple data-placeholder="Escolha os Estudantes" class="chosen-select form-control input-md">
				<option value=""></option>
				<?php $__currentLoopData = $estudantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudante): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<option value="<?php echo e($estudante->id); ?>"><?php echo e($estudante->instituicao->sigla); ?> - <?php echo e($estudante->pessoa->nome); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</select>
		  	<?php if(count($errors)>0): ?>
		  	 	<div class="text-danger">			
					<li style="list-style-type:none"><?php echo e($errors->first('estudantes')); ?></li>
				</div>
			<?php endif; ?>	
		  </div>
		</div>

		<div class="form-group">
		  <div class="col-sm-offset-4 col-md-offset-3 col-sm-8 col-md-6">
			<label class="control-label" for="maquete">
				<input type="checkbox" id="maquete" name="maquete" value="1">
				Este trabalho possui maquete
			</label>			
		  </div>
		</div>

		<div class="form-group">
		  <div class="col-sm-offset-4 col-md-offset-3 col-sm-10">
		    <button class="btn btn-primary" type="submit">Registrar</button>
		    <a href="/evento/trabalhos/<?php echo e($evento->id); ?>" class="btn btn-danger">Cancelar</a>
		  </div>
		</div>		

		</fieldset>
	</form>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>