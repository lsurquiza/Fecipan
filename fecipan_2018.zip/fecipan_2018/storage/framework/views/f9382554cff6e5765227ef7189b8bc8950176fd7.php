<!--esta visão irá aparecer dentro da principal.blade-->

<?php $__env->startSection('conteudo'); ?>

<h1>Perfis Cadastrados</h1>
<hr>
<table class="table table-condensed table-hover table-striped">
	<thead>
		<tr>
			<th>#</th>
			<th>Descrição</th>
			<th>Pessoas</th>
			<th>Perfil Pai</th>
			<th>Perfis Vinculados</th>
			<th>Permissões</th>
			<th>Ações</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $perfis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfil): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($perfil->id); ?></td>
			<td><?php echo e($perfil->descricao); ?></td>
			<td>
				<a href="\perfil\usuarios\<?php echo e($perfil->id); ?>" title="Visualizar usuários cadastrados com o perfil <?php echo e($perfil->descricao); ?>">
					<span class="badge"><?php echo e($perfil->usuarios->count()); ?></span>
				</a>
			</td>
			<td>
				<?php if($perfil->perfil): ?>
				<?php echo e($perfil->perfil->descricao); ?>

				<?php else: ?>
				--
				<?php endif; ?>
			</td>
			<td>
				<a href="\perfil\vinculos\<?php echo e($perfil->id); ?>" title="Visualizar perfis vinculados ao perfil <?php echo e($perfil->descricao); ?>">
					<span class="badge"><?php echo e($perfil->perfis->count()); ?></span>
				</a>
			</td>
			<td>
				<a href="\perfil\permissoes\<?php echo e($perfil->id); ?>" title="Visualizar permissões atribuídas ao perfil <?php echo e($perfil->descricao); ?>">
					<span class="badge"><?php echo e($perfil->conteudos->count()); ?></span>
				</a>
			</td>
			<td>
				<div class="btn-group">
					<a href="\perfil\create\<?php echo e($perfil->id); ?>" class="btn btn-sm btn-primary" title="Cadastrar novo perfil vinculado a <?php echo e($perfil->descricao); ?>">
						<span class="glyphicon glyphicon-link"></span>
					</a>
					<?php if($perfil->administrador == 0 && $perfil->perfis->count() == 0): ?>
					<a href="#" data-toggle="modal" data-target="#delete_<?php echo e($perfil->id); ?>" class="btn btn-sm btn-primary" title="Excluir perfil">
						<span class="glyphicon glyphicon-trash"></span>
					</a>
					<?php endif; ?>
				</div>
				<!-- Modal -->
				<?php if($perfil->administrador == 0 && $perfil->perfis->count() == 0): ?>
				<div id="delete_<?php echo e($perfil->id); ?>" class="modal fade" role="dialog">
				  <div class="modal-dialog">

				    <!-- Modal content-->
				    <div class="modal-content">
				      <div class="modal-header">
				        <button type="button" class="close" data-dismiss="modal">&times;</button>
				        <h4 class="modal-title">
				        	<span class="glyphicon glyphicon-alert"></span>
				        	Exclusão de Perfil
				       	</h4>
				      </div>
				      <div class="modal-body">
				        <p>Confirma a exclusão do perfil <strong><?php echo e($perfil->id); ?> - <?php echo e($perfil->descricao); ?></strong>?</p>
				      </div>
				      <div class="modal-footer">
				        <a href="\perfil\delete\<?php echo e($perfil->id); ?>" class="btn btn-danger">Sim</a>
				        <button type="button" class="btn btn-info" data-dismiss="modal">Não</button>
				      </div>
				    </div>

				  </div>
				</div>
				<?php endif; ?>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>
<hr>
<!--
<a href="\perfil\create" class="btn btn-primary">
	<span class="glyphicon glyphicon-file"></span>
	Cadastrar Perfil
</a>
-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>