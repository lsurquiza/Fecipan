<?php $__env->startSection('conteudo'); ?>

<?php if($permissoes->visualizar): ?>
	<h1>Categoria</h1>
	<hr>
	<?php if($permissoes->inserir): ?>
	  <a href="/categoria/create" class="btn btn-primary"><span class="glyphicon glyphicon-file"></span> Cadastrar Categoria</a><br><br>
	<?php endif; ?>
	<table id="table" class="table table-striped table-hover">
	  <thead>
		<tr>
			<th>#</th>
			<th>Descrição</th>
			<th class="text-right">Ações</th>
		</tr>
	  </thead>
	  <tbody>
	<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($a->id); ?></td>
			<td><?php echo e($a->descricao); ?></td>
			<td class="text-right">
			  <div class="btn-group">
			  <?php if($permissoes->alterar): ?>
				  <a class="btn btn-sm btn-primary" href="/categoria/update/<?php echo e($a->id); ?>" title="Alterar categoria"><span class="glyphicon glyphicon-pencil"></span></a>
			  <?php endif; ?>
			  <?php if($permissoes->excluir): ?>
			    <a href="#" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#<?php echo e($a->id); ?>" title="Excluir categoria"><span class="glyphicon glyphicon-trash"></span></a>
			  <?php endif; ?>
			  </div>
				<div id="<?php echo e($a->id); ?>" class="modal fade text-justify" role="dialog">
				  <div class="site-wrapper">
					<div class="modal-dialog">                
					  <div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">
								<span class="glyphicon glyphicon-alert"></span>
								Exclusão de Categoria
							</h4>
						  </div>
						  
						  <div class="modal-body">
							<p>Confirma a exclusão da categoria <strong><?php echo e($a->id); ?> - <?php echo e($a->descricao); ?></strong>?</p>
						  </div>
						  
						  <div class="modal-footer">
							<a href="/categoria/delete/<?php echo e($a->id); ?>" class="btn btn-danger">Sim</a>
							<a href="/categoria" class="btn btn-info" data-dismiss="modal">Não</a>
						</div>
					  </div>
					</div>
				  </div>
				</div>
			  </td>
			</td>
		</tr>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	  </tbody>
	</table>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>