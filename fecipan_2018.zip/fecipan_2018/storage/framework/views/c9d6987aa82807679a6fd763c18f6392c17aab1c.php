<?php $__env->startSection('conteudo'); ?>

<?php if($permissoes->visualizar): ?>
	<h1><span class="glyphicon glyphicon-education"></span> Orientadores</h1>
	<h3><?php echo e($trabalho->cod); ?> - <?php echo e($trabalho->titulo); ?></h3>
	<h4>
		<?php echo e($trabalho->evento->titulo); ?> 
		<?php echo e($trabalho->evento->ano); ?>/<?php echo e($trabalho->evento->semestre); ?>

	</h4>
	<p><?php echo e($trabalho->evento->tema); ?></p>	
	<hr>
	<div class='text-right'>
	  <a class='btn btn-primary btn-sm' href="/evento/trabalhos/<?php echo e($trabalho->evento_id); ?>">
		Voltar
	  </a>
	</div>
	<?php if($permissoes->inserir == true): ?>
	<a href="\orientacao\create\<?php echo e($trabalho->id); ?>" class="btn btn-primary">
		<span class="glyphicon glyphicon-file"></span>
		Cadastrar Orientadores
	</a>
	<?php endif; ?>
	<br><br>

	<?php $__currentLoopData = $trabalho->orientadores()->orderBy('tipo_orientacao')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		  <div class='panel panel-default'>
			<div class='panel-heading'>
			  <div class='row'>
			  <div class='col-sm-10'>
				<h4><strong><?php echo e($q->pivot->tipo_orientacao==1? "Orientador": "Coorientador"); ?>:</strong> <?php echo e($q->pessoa->nome); ?></h4>
			  </div>
			  <div class='btn-group col-sm-2'>
				  <?php if($permissoes->excluir): ?>
				  <a class='btn btn-primary btn-sm' href="#" data-toggle="modal" data-target="#<?php echo e($q->id); ?>"title="Excluir orientação de #<?php echo e($q->pessoa->nome); ?>">
					<span class="glyphicon glyphicon-trash"></span>
				  </a>
				  <?php endif; ?>
			  </div>
			  </div>
			  <div id="<?php echo e($q->id); ?>" class="modal fade text-justify" role="dialog">
				  <div class="site-wrapper">
					<div class="modal-dialog">                
					  <div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">
								<span class="glyphicon glyphicon-alert"></span>
								Exclusão de Orientador
							</h4>
						  </div>
						  
						  <div class="modal-body">
							<p>Deseja excluir a orientação de <strong><?php echo e($q->id); ?> - <?php echo e($q->pessoa->nome); ?></strong>?</p>
						  </div>
						  
						  <div class="modal-footer">
							<a href="/orientacao/delete/<?php echo e($trabalho->id); ?>/<?php echo e($q->id); ?>" class="btn btn-danger">Sim</a>
							<button class="btn btn-info" data-dismiss="modal">Não</button>
						</div>
					  </div>
					</div>
				  </div>
			  </div>
			</div>
			<div class='panel-body'>
				<div><strong>Escola:</strong> <?php echo e($q->instituicao->sigla); ?> - <?php echo e($q->instituicao->nome); ?></div>
				<div><strong>Cidade:</strong> <?php echo e($q->instituicao->cidade); ?></div>
			</div>
		  </div>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php endif; ?>
	<div class='text-right'>
	  <a class='btn btn-primary btn-sm' href="/evento/trabalhos/<?php echo e($trabalho->evento_id); ?>">
		Voltar
	  </a>
	</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>