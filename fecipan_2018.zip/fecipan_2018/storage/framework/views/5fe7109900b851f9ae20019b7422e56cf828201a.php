<?php $__env->startSection('conteudo'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4>Associar Conteúdo <?php echo e($conteudo->rotulo); ?> a Outros Perfis</h4>
                </div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/conteudo/associar')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="conteudo_id" value="<?php echo e($conteudo->id); ?>" readonly required autofocus>
						
                        <div class="form-group<?php echo e($errors->has('rota') ? ' has-error' : ''); ?>">
                            <label for="rota" class="col-md-4 control-label">Rota</label>

                            <label class="col-md-6 text-info bg-info">
                                <?php echo e($conteudo->rota); ?>

                            </label>
                        </div>

                        <div class="form-group<?php echo e($errors->has('rotulo') ? ' has-error' : ''); ?>">
                            <label for="rotulo" class="col-md-4 control-label">Rótulo</label>

                            <label class="col-md-6 text-info bg-info">
                                <?php echo e($conteudo->rotulo); ?>

                            </label>
                        </div>

                        <div class="form-group<?php echo e($errors->has('publica') ? ' has-error' : ''); ?>">
                            <label for="publica" class="col-md-4 control-label">
                                Visibilidade Pública
                            </label>
                            <label class="col-md-6 text-info bg-info">
								<?php echo e($conteudo->publica? "Sim": "Não"); ?>

							</label>
                        </div>

                        <div class="form-group<?php echo e($errors->has('menu') ? ' has-error' : ''); ?>">
                            <label for="menu" class="col-md-4 control-label">
                                Exibir no Menu
                            </label>
                            <label class="col-md-6 text-info bg-info">
								<?php echo e($conteudo->menu? "Sim": "Não"); ?>

							</label>
                        </div>
						
						<hr>
						<h4>Escolha o Perfil para Associar</h5>
                        <div class="form-group<?php echo e($errors->has('perfil_id') ? ' has-error' : ''); ?>">
                            <label for="perfil_id" class="col-md-4 control-label">
                                Perfil
                            </label>
                            <div class="col-md-6">
                                <select id="perfil_id" data-placeholder="Selecione o perfil..." class="chosen-select form-control" name="perfil_id">
									<option value=""></option>
									<?php $__currentLoopData = $perfis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfil): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
									<option value="<?php echo e($perfil->id); ?>"><?php echo e($perfil->descricao); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
								</select>
                                <?php if($errors->has('perfil_id')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('perfil_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
						<hr>
						<h4>Permissões</h5>
						
                        <div class="form-group<?php echo e($errors->has('visualizar') ? ' has-error' : ''); ?>">
                            <label for="visualizar" class="col-md-4 control-label">
                                O usuário pode visualizar
                            </label>
                            <div class="col-md-6">
                                <input type="checkbox" id="visualizar" name="visualizar" <?php echo e(old('visualizar')? "checked": ""); ?>>

                                <?php if($errors->has('visualizar')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('visualizar')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('inserir') ? ' has-error' : ''); ?>">
                            <label for="inserir" class="col-md-4 control-label">
                                O usuário pode inserir
                            </label>
                            <div class="col-md-6">
                                <input type="checkbox" id="inserir" name="inserir" <?php echo e(old('inserir')? "checked": ""); ?>>

                                <?php if($errors->has('inserir')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('inserir')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('alterar') ? ' has-error' : ''); ?>">
                            <label for="alterar" class="col-md-4 control-label">
                                O usuário pode alterar
                            </label>
                            <div class="col-md-6">
                                <input type="checkbox" id="alterar" name="alterar" <?php echo e(old('alterar')? "checked": ""); ?>>

                                <?php if($errors->has('alterar')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('alterar')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('excluir') ? ' has-error' : ''); ?>">
                            <label for="excluir" class="col-md-4 control-label">
                                O usuário pode excluir
                            </label>
                            <div class="col-md-6">
                                <input type="checkbox" id="excluir" name="excluir" <?php echo e(old('excluir')? "checked": ""); ?>>

                                <?php if($errors->has('excluir')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('excluir')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Registrar
                                </button>
                                <a href="/conteudo/permissoes/<?php echo e($conteudo->id); ?>" class="btn btn-danger">
                                    Cancelar
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>