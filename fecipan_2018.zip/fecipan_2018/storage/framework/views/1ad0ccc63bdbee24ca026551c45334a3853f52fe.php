<?php $__env->startSection('conteudo'); ?>
<div class="panel panel-default">
	<div class="panel-heading">
		<h4>Cadastro de Quesito para o Evento <?php echo e($evento->nome); ?> <?php echo e($evento->ano); ?>/<?php echo e($evento->semestre); ?></h4>
	</div>
	<div class="panel-body">
	<form class="form-horizontal" action="/quesito/create" method="POST">
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
		<input type="hidden" name="evento_id" value="<?php echo e($evento->id); ?>" />
		<fieldset>
		
		<div class="form-group">
		  <label class="col-sm-4 col-md-3 control-label" for="enunciado">Enunciado</label>  
		  <div class="col-sm-8 col-md-6">
		  	<input id="enunciado" name="enunciado" type="text" placeholder="Enunciado do Quesito" class="form-control input-md" value="<?php echo e(old('enunciado')); ?>">
		  	<?php if(count($errors)>0): ?>
		  	 	<div class="text-danger">			
					<li style="list-style-type:none"><?php echo e($errors->first('enunciado')); ?></li>
				</div>
			<?php endif; ?>	
		  </div>
		</div>

		<div class="form-group">
		  <label class="col-sm-4 col-md-3 control-label" for="peso">Peso</label>  
		  <div class="col-sm-3 col-md-2">
		  	<input id="peso" name="peso" type="number" min="0" placeholder="Peso do Quesito" class="form-control input-md" value="<?php echo e(old('peso')); ?>">
		  	<?php if(count($errors)>0): ?>
		  	 	<div class="text-danger">			
					<li style="list-style-type:none"><?php echo e($errors->first('peso')); ?></li>
				</div>
			<?php endif; ?>	
		  </div>
		</div>

		<div class="form-group">
		  <div class="col-sm-offset-4 col-md-offset-3 col-sm-10">
		    <button class="btn btn-primary" type="submit">Registrar</button>
		    <a href="/evento/quesitos/<?php echo e($evento->id); ?>" class="btn btn-danger">Cancelar</a>
		  </div>
		</div>		

		</fieldset>
	</form>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>