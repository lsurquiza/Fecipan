<!--esta visão irá aparecer dentro da principal.blade-->

<?php $__env->startSection('conteudo'); ?>

<h1>Estados Civis</h1>
<table class="table table-condensed table-hover table-striped">
	<thead>
		<tr>
			<th>#</th>
			<th>Descrição</th>
			<th>Pessoas</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $estados_civis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado_civil): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($estado_civil->id); ?></td>
			<td><?php echo e($estado_civil->descricao); ?></td>
			<td><?php echo e($estado_civil->usuarios->count()); ?></td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>