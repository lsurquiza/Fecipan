<?php $__env->startSection('conteudo'); ?>

	<h1>Avaliador: <?php echo e($avaliador->pessoa->nome); ?> - <?php echo e($avaliador->area); ?></h1>
	<h4><?php echo e($avaliador->instituicao->sigla); ?> - <?php echo e($avaliador->instituicao->nome); ?></h4>
	<div>Trabalhos Cadastrados</div>
	<hr>
	<div class='text-right'>
	  <a class='btn btn-primary btn-sm' href="/pessoa/avaliadores">
		Voltar
	  </a>
	</div><br><br>

	<table id="table" class="table table-condensed table-hover table-striped">
		<thead>
		  <tr>
			<th>ID</th>
			<th>Evento</th>
			<th>Código do Trabalho</th>
			<th>Titulo</th>
			<th>Tipo de Trabalho</th>
			<th>Área</th>
			<th>Categoria</th>
		  </tr>
		</thead>
		<tbody>
	<?php $__currentLoopData = $avaliador->avaliacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		  <tr>
			<td><?php echo e($t->trabalho->id); ?></td>
			<td><?php echo e($t->trabalho->evento->ano); ?>/<?php echo e($t->trabalho->evento->semestre); ?> <?php echo e($t->trabalho->evento->titulo); ?></td>
			<td><?php echo e($t->trabalho->cod); ?></td>
			<td><?php echo e($t->trabalho->titulo); ?></td>
			<td><?php echo e($t->trabalho->tipoTrabalho->nome); ?></td>
			<td><?php echo e($t->trabalho->area->area); ?></td>
			<td><?php echo e($t->trabalho->categoria->descricao); ?></td>
		  </tr>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</tbody>
	</table>
	<div class='text-right'>
	  <a class='btn btn-primary btn-sm' href="/pessoa/avaliadores">
		Voltar
	  </a>
	</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>