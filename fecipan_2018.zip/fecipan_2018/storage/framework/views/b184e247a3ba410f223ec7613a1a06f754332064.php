<!--esta visão irá aparecer dentro da principal.blade-->

<?php $__env->startSection('conteudo'); ?>

<h1>Perfis Vinculados ao Perfil <?php echo e($perfil->descricao); ?></h1>
<hr>
<div class='text-right'>
  <a class='btn btn-primary btn-sm' href="/perfil">
	Voltar
  </a>
</div>
<a href="\perfil\create\<?php echo e($perfil->id); ?>" class="btn btn-primary">
	<span class="glyphicon glyphicon-link"></span>
	Vincular Perfil a <?php echo e($perfil->descricao); ?>

</a><br><br>
<table id="table" class="table table-condensed table-hover table-striped">
	<thead>
		<tr>
			<th>#</th>
			<th>Descrição</th>
			<th class="text-right">Usuários</th>
			<th class="text-right">Perfis Vinculados</th>
			<th class="text-right">Ações</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $perfil->perfis_vinculados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vinculo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($vinculo->id); ?></td>
			<td><?php echo e($vinculo->descricao); ?></td>
			<td class="text-right">
				<a class="btn btn-primary btn-sm" href="\perfil\usuarios\<?php echo e($vinculo->id); ?>" title="Visualizar perfis vinculados">
					<?php echo e($vinculo->usuarios->count()); ?>

				</a>
			</td>
			<td class="text-right">
				<a class="btn btn-primary btn-sm" href="\perfil\vinculos\<?php echo e($vinculo->id); ?>" title="Visualizar perfis vinculados">
					<?php echo e($vinculo->perfis_vinculados->count()); ?>

				</a>
			</td>
			<td class="text-right">
				<div class="btn-group">
					<a href="\perfil\create\<?php echo e($vinculo->id); ?>" class="btn btn-sm btn-primary" title="Vincular perfil a <?php echo e($vinculo->descricao); ?>">
						<span class="glyphicon glyphicon-link"></span>
					</a>
					<?php if($vinculo->administrador == 0): ?>
					<a href="#" data-toggle="modal" data-target="#delete_<?php echo e($vinculo->id); ?>" class="btn btn-sm btn-primary" title="Excluir perfil">
						<span class="glyphicon glyphicon-trash"></span>
					</a>
					<?php endif; ?>
				</div>
				<!-- Modal -->
				<?php if($vinculo->administrador == 0): ?>
				<div id="delete_<?php echo e($vinculo->id); ?>" class="modal fade text-justify" role="dialog">
				  <div class="modal-dialog">

				    <!-- Modal content-->
				    <div class="modal-content">
				      <div class="modal-header">
				        <button type="button" class="close" data-dismiss="modal">&times;</button>
				        <h4 class="modal-title">
				        	<span class="glyphicon glyphicon-alert"></span>
				        	Exclusão de Perfil
				       	</h4>
				      </div>
				      <div class="modal-body">
				        <p>Confirma a exclusão do perfil <strong><?php echo e($vinculo->id); ?> - <?php echo e($vinculo->descricao); ?></strong>?</p>
				      </div>
				      <div class="modal-footer">
				        <a href="\perfil\delete\<?php echo e($vinculo->id); ?>" class="btn btn-danger">Sim</a>
				        <button type="button" class="btn btn-info" data-dismiss="modal">Não</button>
				      </div>
				    </div>

				  </div>
				</div>
				<?php endif; ?>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>
<div class='text-right'>
  <a class='btn btn-primary btn-sm' href="/perfil">
	Voltar
  </a>
</div><br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>