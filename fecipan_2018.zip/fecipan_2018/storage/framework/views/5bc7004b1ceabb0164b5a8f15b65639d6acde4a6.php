<?php $__env->startSection('conteudo'); ?>

	<h1>Estudante: <?php echo e($estudante->pessoa->nome); ?></h1>
	<h4><?php echo e($estudante->instituicao->sigla); ?> - <?php echo e($estudante->instituicao->nome); ?></h4>
	<div>Trabalhos Cadastrados</div>
	<hr>
	<div class='text-right'>
	  <a class='btn btn-primary btn-sm' href="/pessoa/estudantes">
		Voltar
	  </a>
	</div><br><br>
	<table id="table" class="table table-condensed table-hover table-striped">
		<thead>
		  <tr>
			<th>ID</th>
			<th>Evento</th>
			<th>Código do Trabalho</th>
			<th>Titulo</th>
			<th>Tipo de Trabalho</th>
			<th>Área</th>
			<th>Categoria</th>
		  </tr>
		</thead>
		<tbody>
	<?php $__currentLoopData = $estudante->trabalhos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		  <tr>
			<td><?php echo e($t->id); ?></td>
			<td><?php echo e($t->evento->ano); ?>/<?php echo e($t->evento->semestre); ?> <?php echo e($t->evento->titulo); ?></td>
			<td><?php echo e($t->cod); ?></td>
			<td><?php echo e($t->titulo); ?></td>
			<td><?php echo e($t->tipoTrabalho->nome); ?></td>
			<td><?php echo e($t->area->area); ?></td>
			<td><?php echo e($t->categoria->descricao); ?></td>
		  </tr>
	  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</tbody>
	</table>
	<div class='text-right'>
	  <a class='btn btn-primary btn-sm' href="/pessoa/estudantes">
		Voltar
	  </a>
	</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>