<?php $__env->startSection('conteudo'); ?>
<div class="panel panel-default">
	<div class="panel-heading">
		<h4>
			Associar Estudante ao Trabalho <?php echo e($trabalho->cod); ?>

		</h4>
		<p><?php echo e($trabalho->titulo); ?></p>
	</div>
	<div class="panel-body">
	<form class="form-horizontal" action="/participacao/create" method="POST">
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
		<input type="hidden" name="trabalho_id" value="<?php echo e($trabalho->id); ?>" />
		<fieldset>
		
		<div class="form-group">
		  <label class="col-sm-4 col-md-3 control-label" for="estudantes">Estudantes</label>  
		  <div class="col-sm-8 col-md-6">
		  	<select id="estudantes" name="estudantes[]" data-placeholder="Selecione os estudantes..." multiple class="chosen-select form-control input-md">
				<option value=""></option>
				<?php $__currentLoopData = $estudantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudante): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<option value="<?php echo e($estudante->id); ?>"><?php echo e($estudante->instituicao->sigla); ?> - <?php echo e($estudante->pessoa->nome); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</select>
		  	<?php if(count($errors)>0): ?>
		  	 	<div class="text-danger">			
					<li style="list-style-type:none"><?php echo e($errors->first('estudantes')); ?></li>
				</div>
			<?php endif; ?>	
		  </div>
		</div>

		<div class="form-group">
		  <div class="col-sm-offset-4 col-md-offset-3 col-sm-10">
		    <button class="btn btn-primary" type="submit">Registrar</button>
		    <a href="/trabalho/estudantes/<?php echo e($trabalho->id); ?>" class="btn btn-danger">Cancelar</a>
		  </div>
		</div>		

		</fieldset>
	</form>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>