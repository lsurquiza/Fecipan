<?php $__env->startSection('conteudo'); ?>

<h1>Conteúdos Cadastrados</h1>
<hr>
<a href="\conteudo\create" class="btn btn-primary"><span class="glyphicon glyphicon-file"></span> Cadastrar Conteúdo</a><br><br>
<table id="table" class="table table-condensed table-hover table-striped">
	<thead>
		<tr>
			<th>#</th>
			<th>Rota</th>
			<th>Rótulo</th>
			<th>Visibilidade</th>
			<th>Menu</th>
			<th class="text-right">Permissões</th>
			<th class="text-right">Ações</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $conteudos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conteudo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($conteudo->id); ?></td>
			<td><?php echo e($conteudo->rota); ?></td>
			<td><?php echo e($conteudo->rotulo); ?></td>
			<td><?php echo e($conteudo->publica == true? 'Público': 'Privado'); ?></td>
			<td><?php echo e($conteudo->menu == true? 'Sim': 'Não'); ?></td>
			<td class="text-right">
				<a class="btn btn-primary btn-sm" href="\conteudo\permissoes\<?php echo e($conteudo->id); ?>" title="Visualizar perfis com acesso a este conteúdo">
					<?php echo e($conteudo->perfis->count()); ?>

				</a>
			</td>
			<td class="text-right">
				<div class="btn-group">
					<a href="\conteudo\update\<?php echo e($conteudo->id); ?>" class="btn btn-sm btn-primary" title="Alterar conteúdo">
						<span class="glyphicon glyphicon-edit"></span>
					</a>
					<a href="#" data-toggle="modal" data-target="#delete_<?php echo e($conteudo->id); ?>" class="btn btn-sm btn-primary" title="Excluir usuario">
						<span class="glyphicon glyphicon-trash"></span>
					</a>
				</div>
				<!-- Modal -->
				<div id="delete_<?php echo e($conteudo->id); ?>" class="modal fade text-justify" role="dialog">
				  <div class="modal-dialog">

				    <!-- Modal content-->
				    <div class="modal-content">
				      <div class="modal-header">
				        <button type="button" class="close" data-dismiss="modal">&times;</button>
				        <h4 class="modal-title">
				        	<span class="glyphicon glyphicon-alert"></span>
				        	Exclusão de Usuário
				       	</h4>
				      </div>
				      <div class="modal-body">
				        <p>Confirma a exclusão do conteúdo <strong><?php echo e($conteudo->id); ?> - <?php echo e($conteudo->rotulo); ?></strong>?</p>
				      </div>
				      <div class="modal-footer">
				        <a href="\conteudo\delete\<?php echo e($conteudo->id); ?>" class="btn btn-danger">Sim</a>
				        <button type="button" class="btn btn-info" data-dismiss="modal">Não</button>
				      </div>
				    </div>

				  </div>
				</div>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>