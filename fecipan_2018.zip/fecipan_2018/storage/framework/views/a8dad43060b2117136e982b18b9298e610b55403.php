<?php $__env->startSection('conteudo'); ?>

<?php if($permissoes->visualizar): ?>
	<h1>
		Trabalhos Cadastrados na
		<?php echo e($evento->titulo); ?> <?php echo e($evento->ano); ?>/<?php echo e($evento->semestre); ?>

	</h1>
	<p>
		<?php echo e($evento->tema); ?>

	</p>
	<hr>
	<div class='text-right'>
	  <a class='btn btn-primary btn-sm' href="/evento">
		Voltar
	  </a>
	</div>
	<?php if($permissoes->inserir == true): ?>
	<a href="\trabalho\create\<?php echo e($evento->id); ?>" class="btn btn-primary">
		<span class="glyphicon glyphicon-file"></span>
		Cadastrar Trabalho
	</a>
	<?php endif; ?>
	<br><br>

        <script>
$(document).ready( function () {
    $('#tableTrabalhos').DataTable(
		{
			"order": [[ 7, "desc" ]]
		} );
} );
		</script>
	<table id="tableTrabalhos" class="table table-condensed table-hover table-striped">
		<thead>
		  <tr>
			<th>Cod</th>
			<th>Trabalho</th>
			<th>Tipo</th>
			<th>Categoria</th>
			<th class='text-right'>Avaliações Feitas</th>
			<th class='text-right'>Estudantes</th>
			<th class='text-right'>Orientadores</th>
			<th class='text-right'>Média</th>
			<th class='text-right'>Ações</th>
		  </tr>
		</thead>
		<tbody>
		<?php $__currentLoopData = $evento->trabalhos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		  <tr>
			<td><?php echo e($t->cod); ?></td>
			<td><?php echo e($t->titulo); ?></td>
			<td><?php echo e($t->tipoTrabalho->nome); ?></td>
			<td><?php echo e($t->categoria->descricao); ?></td>
			<td class='text-right'>
				<a class="btn btn-primary btn-xs" href="\trabalho\avaliacoes\<?php echo e($t->id); ?>" title="Visualizar avaliações para o trabalho <?php echo e($t->cod); ?>">
					<?php echo e($t->avaliacoes->where("notas_lancadas", 1)->count()); ?> de <?php echo e($t->avaliacoes->count()); ?>

				</a>
			</td>
			<td class='text-right'>
				<a class="btn btn-primary btn-xs" href="\trabalho\estudantes\<?php echo e($t->id); ?>" title="Visualizar estudantes do trabalho <?php echo e($t->cod); ?>">
					<?php echo e($t->estudantes->count()); ?>

				</a>
			</td>
			<td class='text-right'>
				<a class="btn btn-primary btn-xs" href="\trabalho\orientadores\<?php echo e($t->id); ?>" title="Visualizar orientadores do trabalho <?php echo e($t->cod); ?>">
					<?php echo e($t->orientadores->count()); ?>

				</a>
			</td>
			<td class="text-right">
			<?php 
				$avaliacoes = $t->avaliacoes->where('notas_lancadas', 1)->count();
				$somatorio= 0;
				foreach ($t->avaliacoes->where('notas_lancadas', 1) as $a):
					foreach ($a->notas as $nota):
						$somatorio += $nota->valor * $nota->quesito->peso;
					endforeach;
				endforeach;
				$media = $avaliacoes == 0? "0": $somatorio/$avaliacoes;
				printf("<h5>%.2f</h5>", $media); 
			?>
			</td>
			<td>
			  <div class='btn-group'>
				  <?php if($permissoes->alterar): ?>
				  <a class='btn btn-primary btn-xs' href="/trabalho/update/<?php echo e($t->id); ?>" title="Alterar trabalho #<?php echo e($t->id); ?>"> 
					<span class="glyphicon glyphicon-pencil"></span>
				  </a>
				  <?php endif; ?>
				  <?php if($permissoes->excluir): ?>
				  <a class='btn btn-primary btn-xs' href="#" data-toggle="modal" data-target="#<?php echo e($t->id); ?>"title="Excluir trabalho #<?php echo e($t->id); ?>">
					<span class="glyphicon glyphicon-trash"></span>
				  </a>
				  <?php endif; ?>
			  </div>
			  <div id="<?php echo e($t->id); ?>" class="modal fade text-justify" role="dialog">
				  <div class="site-wrapper">
					<div class="modal-dialog">                
					  <div class="modal-content">
						  <div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">
								<span class="glyphicon glyphicon-alert"></span>
								Exclusão de Trabalho
							</h4>
						  </div>
						  
						  <div class="modal-body">
							<p>Deseja excluir o trabalho <strong><?php echo e($t->id); ?> - <?php echo e($t->cod); ?></strong>?</p>
						  </div>
						  
						  <div class="modal-footer">
							<a href="/trabalho/delete/<?php echo e($t->id); ?>" class="btn btn-danger">Sim</a>
							<button class="btn btn-info" data-dismiss="modal">Não</button>
						</div>
					  </div>
					</div>
				  </div>
			  </div>
			</td>
		  </tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</tbody>
	</table>
	<div class='text-right'>
	  <a class='btn btn-primary btn-sm' href="/evento">
		Voltar
	  </a>
	</div>
<?php endif; ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>