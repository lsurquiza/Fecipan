<?php $__env->startSection('conteudo'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4>
                        Cadastro de Usuário
                        <?php if($perfis->count() == 1): ?>
                            com Perfil de <?php echo e($perfis[0]->descricao); ?>

                        <?php endif; ?>
                    </h4>
                </div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/usuario/create')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('nome') ? ' has-error' : ''); ?>">
                            <label for="nome" class="col-md-4 control-label">Nome</label>

                            <div class="col-md-6">
                                <input id="nome" type="text" class="form-control" name="nome" value="<?php echo e(old('nome')); ?>" required autofocus>

                                <?php if($errors->has('nome')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('nome')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('cpf') ? ' has-error' : ''); ?>">
                            <label for="cpf" class="col-md-4 control-label">CPF</label>

                            <div class="col-md-6">
                                <input id="cpf" type="text" class="form-control" name="cpf" value="<?php echo e(old('cpf')); ?>" required>

                                <?php if($errors->has('cpf')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('cpf')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('sexo') ? ' has-error' : ''); ?>">
                            <label class="col-md-4 control-label">Sexo</label>

                            <div class="col-md-6">
                                <label class="label-inline">
                                    <input id="sexo" type="radio" value="F" name="sexo" <?php echo e(old('sexo') == 'F'? 'checked': ''); ?>>
                                    Feminino
                                </label>
                                <label class="label-inline">
                                    <input id="sexo" type="radio" value="M" name="sexo" <?php echo e(old('sexo') == 'M'? 'checked': ''); ?>>
                                    Masculino
                                </label>

                                <?php if($errors->has('sexo')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('sexo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('data_de_nascimento') ? ' has-error' : ''); ?>">
                            <label for="data_de_nascimento" class="col-md-4 control-label">Data de Nascimento</label>

                            <div class="col-md-6">
                                <input id="data_de_nascimento" type="date" class="form-control" name="data_de_nascimento" value="<?php echo e(old('data_de_nascimento')); ?>">

                                <?php if($errors->has('data_de_nascimento')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('data_de_nascimento')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('pais_id') ? ' has-error' : ''); ?>">
                            <label for="pais_id" class="col-md-4 control-label">Nacionalidade</label>

                            <div class="col-md-6">
                                <select id="pais_id" class="form-control" name="pais_id">
                                    <option>Selecione...</option>
                                    <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <option value="<?php echo e($pais->id); ?>" <?php echo e(old('pais_id') == $pais->id? 'selected': ''); ?>>
                                        <?php echo e($pais->nome); ?> / <?php echo e($pais->gentilico); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>                                    
                                </select>

                                <?php if($errors->has('pais_id')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('pais_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <?php if($perfis->count() > 1): ?>
                        <div class="form-group<?php echo e($errors->has('perfil_id') ? ' has-error' : ''); ?>">
                            <label for="perfil_id" class="col-md-4 control-label">Perfil</label>

                            <div class="col-md-6">
                                <select id="perfil_id" class="form-control" name="perfil_id">
                                    <option>Selecione...</option>
                                    <?php $__currentLoopData = $perfis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfil): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <option value="<?php echo e($perfil->id); ?>" <?php echo e(old('perfil_id') == $perfil->id? 'selected': ''); ?>>
                                        <?php echo e($perfil->descricao); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>                                    
                                </select>

                                <?php if($errors->has('perfil_id')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('perfil_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <div class="form-group<?php echo e($errors->has('estado_civil_id') ? ' has-error' : ''); ?>">
                            <label for="estado_civil_id" class="col-md-4 control-label">Estado Civil</label>

                            <div class="col-md-6">
                                <select id="estado_civil_id" class="form-control" name="estado_civil_id">
                                    <option>Selecione...</option>
                                    <?php $__currentLoopData = $estados_civis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado_civil): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <option value="<?php echo e($estado_civil->id); ?>" <?php echo e(old('estado_civil_id') == $estado_civil->id? 'selected': ''); ?>>
                                        <?php echo e($estado_civil->descricao); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>                                    
                                </select>

                                <?php if($errors->has('estado_civil_id')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('estado_civil_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" class="col-md-4 control-label">E-Mail</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('login') ? ' has-error' : ''); ?>">
                            <label for="login" class="col-md-4 control-label">Login</label>

                            <div class="col-md-6">
                                <input id="login" type="text" class="form-control" name="login" value="<?php echo e(old('login')); ?>" required>

                                <?php if($errors->has('login')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('login')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password" class="col-md-4 control-label">Senha</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Confirmar Senha</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Registrar
                                </button>
                                <a href="\usuario" class="btn btn-danger">
                                    Cancelar
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>