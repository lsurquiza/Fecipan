<!--esta visão irá aparecer dentro da principal.blade-->

<?php $__env->startSection('conteudo'); ?>

<h1>Conteúdos Cadastrados</h1>
<hr>
<table class="table table-condensed table-hover table-striped">
	<thead>
		<tr>
			<th>#</th>
			<th>Link</th>
			<th>Rótulo</th>
			<th>Visibilidade</th>
			<th>Menu</th>
			<th>Permissões</th>
			<th>Ações</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $conteudos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conteudo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($conteudo->id); ?></td>
			<td><?php echo e($conteudo->link); ?></td>
			<td><?php echo e($conteudo->rotulo); ?></td>
			<td><?php echo e($conteudo->publica == true? 'Público': 'Privado'); ?></td>
			<td><?php echo e($conteudo->menu == true? 'Sim': 'Não'); ?></td>
			<td><?php echo e($conteudo->permissoes->count()); ?></td>
			<td>--</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>

<a href="\conteudo\create" class="btn btn-primary">
	<span class="glyphicon glyphicon-file"></span>
	Cadastrar Conteúdo
</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>