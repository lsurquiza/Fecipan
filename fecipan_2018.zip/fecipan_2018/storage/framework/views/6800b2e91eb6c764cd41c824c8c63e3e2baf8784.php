<?php $__env->startSection('conteudo'); ?>

<?php if($permissoes->visualizar == true): ?>
	<h1>Ranking da <?php echo e($evento->titulo); ?> <?php echo e($evento->ano); ?>/<?php echo e($evento->semestre); ?></h1>
	<p><?php echo e($evento->tema); ?></p>
	<hr>
	<div class='text-right'>
	  <a class='btn btn-primary btn-sm' href="/evento">
		Voltar
	  </a>
	</div>
	<br><br>
	<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	<h3><?php echo e($c->descricao); ?></h3>
	<div class="panel-group" id="accordion<?php echo e($c->id); ?>">
        <script>
$(document).ready( function () {
    $('#table<?php echo e($c->id); ?>').DataTable(
		{
			"order": [[ 4, "desc" ]]
		} );
} );
		</script>
<?php 
	$trabalhos = $evento->trabalhos()
	->where('trabalho.categoria_id', $c->id)
	->get()
?>
	  <div class="panel panel-default">
		<div class="panel-heading">
		  <h4 class="panel-title">
			<a data-toggle="collapse" data-parent="#accordion<?php echo e($c->id); ?>" href="#collapse<?php echo e($c->id); ?>">
			Geral ( <?php echo e($trabalhos->count()); ?> )
			<span class="caret"></span>
			</a>
		  </h4>
		</div>
		<div id="collapse<?php echo e($c->id); ?>" class="panel-collapse collapse">
		  <div class="panel-body">
			<table id="table<?php echo e($c->id); ?>" class="table table-condensed table-hover table-striped">
			  <thead>
				<tr>
					<th>Cod</th>
					<th>Área</th>
					<th>Título</th>
					<th>Tipo</th>
					<th>Média</th>
				</tr>
			  </thead>
			  <tbody>
				<?php $__currentLoopData = $trabalhos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<tr>
					<td><?php echo e($t->cod); ?></td>
					<td><?php echo e($t->area->area); ?></td>
					<td><?php echo e($t->titulo); ?></td>
					<td><?php echo e($t->tipoTrabalho->nome); ?></td>
					<td>
					<?php 
						$avaliacoes = $t->avaliacoes->where('notas_lancadas', 1)->count();
						$somatorio= 0;
						foreach ($t->avaliacoes->where('notas_lancadas', 1) as $a):
							foreach ($a->notas as $nota):
								$somatorio += $nota->valor * $nota->quesito->peso;
							endforeach;
						endforeach;
						$media = $avaliacoes == 0? "0": $somatorio/$avaliacoes;
						printf("<h5>%.2f</h5>", $media); 
					?>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			  </tbody>
			</table>
		  </div>
		</div>
	  </div>
	  <br>
	<?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <script>
$(document).ready( function () {
    $('#table<?php echo e($c->id); ?>_<?php echo e($a->id); ?>').DataTable(
		{
			"order": [[ 3, "desc" ]]
		} );
} );
		</script>
<?php 
	$trabalhos = $evento->trabalhos()
	->where('trabalho.categoria_id', $c->id)
	->whereIn('trabalho.area_id', [$a->id])
	->get()
?>
	  <div class="panel panel-default">
		<div class="panel-heading">
		  <h4 class="panel-title">
			<a data-toggle="collapse" data-parent="#accordion<?php echo e($c->id); ?>" href="#collapse<?php echo e($c->id); ?>_<?php echo e($a->id); ?>">
			<?php echo e($a->sigla); ?> - <?php echo e($a->area); ?> ( <?php echo e($trabalhos->count()); ?> )
			<span class="caret"></span>
			</a>
		  </h4>
		</div>
		<div id="collapse<?php echo e($c->id); ?>_<?php echo e($a->id); ?>" class="panel-collapse collapse">
		  <div class="panel-body">
			<table id="table<?php echo e($c->id); ?>_<?php echo e($a->id); ?>" class="table table-condensed table-hover table-striped">
			  <thead>
				<tr>
					<th>Cod</th>
					<th>Título</th>
					<th>Tipo</th>
					<th>Média</th>
				</tr>
			  </thead>
			  <tbody>
				<?php $__currentLoopData = $trabalhos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<tr>
					<td><?php echo e($t->cod); ?></td>
					<td><?php echo e($t->titulo); ?></td>
					<td><?php echo e($t->tipoTrabalho->nome); ?></td>
					<td>
					<?php 
						$avaliacoes = $t->avaliacoes->where('notas_lancadas', 1)->count();
						$somatorio= 0;
						foreach ($t->avaliacoes->where('notas_lancadas', 1) as $a):
							foreach ($a->notas as $nota):
								$somatorio += $nota->valor * $nota->quesito->peso;
							endforeach;
						endforeach;
						$media = $avaliacoes == 0? "0": $somatorio/$avaliacoes;
						printf("<h5>%.2f</h5>", $media); 
					?>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			  </tbody>
			</table>
		  </div>
		</div>
	  </div>
	<br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	<hr>
	</div>	
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	<div class='text-right'>
	  <a class='btn btn-primary btn-sm' href="/evento">
		Voltar
	  </a>
	</div>
<?php endif; ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>