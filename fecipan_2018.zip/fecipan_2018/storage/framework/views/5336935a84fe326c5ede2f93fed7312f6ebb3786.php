<!--esta visão irá aparecer dentro da principal.blade-->

<?php $__env->startSection('conteudo'); ?>

<h1>Perfis Cadastrados</h1>
<hr>
<table class="table table-condensed table-hover table-striped">
	<thead>
		<tr>
			<th>#</th>
			<th>Descrição</th>
			<th>Pessoas</th>
			<th>Ações</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $perfis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfil): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($perfil->id); ?></td>
			<td><?php echo e($perfil->descricao); ?></td>
			<td><?php echo e($perfil->usuarios->count()); ?></td>
			<td>
				<div class="btn-group">
					<!--
					<a href="\perfil\update\<?php echo e($perfil->id); ?>" class="btn btn-sm btn-primary" title="Alterar perfil">
						<span class="glyphicon glyphicon-edit"></span>
					</a>
					-->
					<a href="#" data-toggle="modal" data-target="#delete_<?php echo e($perfil->id); ?>" class="btn btn-sm btn-primary" title="Excluir perfil">
						<span class="glyphicon glyphicon-trash"></span>
					</a>
				</div>
				<!-- Modal -->
				<div id="delete_<?php echo e($perfil->id); ?>" class="modal fade" role="dialog">
				  <div class="modal-dialog">

				    <!-- Modal content-->
				    <div class="modal-content">
				      <div class="modal-header">
				        <button type="button" class="close" data-dismiss="modal">&times;</button>
				        <h4 class="modal-title">
				        	<span class="glyphicon glyphicon-alert"></span>
				        	Exclusão de Perfil
				       	</h4>
				      </div>
				      <div class="modal-body">
				        <p>Confirma a exclusão do perfil <strong><?php echo e($perfil->id); ?> - <?php echo e($perfil->descricao); ?></strong>?</p>
				      </div>
				      <div class="modal-footer">
				        <a href="\perfil\delete\<?php echo e($perfil->id); ?>" class="btn btn-danger">Sim</a>
				        <button type="button" class="btn btn-info" data-dismiss="modal">Não</button>
				      </div>
				    </div>

				  </div>
				</div>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>
<hr>
<a href="\perfil\create" class="btn btn-primary">
	<span class="glyphicon glyphicon-file"></span>
	Cadastrar Perfil
</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>