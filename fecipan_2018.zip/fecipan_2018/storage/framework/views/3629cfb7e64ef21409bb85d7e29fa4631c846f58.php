<?php $__env->startSection('conteudo'); ?>
<div class="panel panel-default">
	<div class="panel-heading">
		<h4>Editar de Evento #<?php echo e($e->id); ?></h4>
	</div>
	<div class="panel-body">
	<form class="form-horizontal" action="/evento/update" method="POST">
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
		<input type="hidden" name="evento_id" value="<?php echo e($e->id); ?>" />
		<fieldset>

		<div class="form-group">
		  <label class="col-sm-4 col-md-3 control-label" for="titulo">Título</label>  
		  <div class="col-sm-8 col-md-6">
		  	<input id="titulo" name="titulo" type="text"  value="<?php echo e($e->titulo); ?>" placeholder="Digite o título do evento" class="form-control input-md">
		  	<?php if(count($errors)>0): ?>
		  	 	<div class="text-danger">			
					<li style="list-style-type:none"><?php echo e($errors->first('titulo')); ?></li>
				</div>
			<?php endif; ?>	
		  </div>
		</div>

		<div class="form-group">
		  <label class="col-sm-4 col-md-3 control-label" for="ano">Ano</label>  
		  <div class="col-sm-3 col-md-2">
		  	<input id="ano" name="ano" type="number" value="<?php echo e($e->ano); ?>" placeholder="Digite o ano do evento" class="form-control input-md">
		  	<?php if(count($errors)>0): ?>
		  	 	<div class="text-danger">			
					<li style="list-style-type:none"><?php echo e($errors->first('ano')); ?></li>
				</div>
			<?php endif; ?>	
		  </div>
		</div>


		<div class="form-group">
		  <label class="col-sm-4 col-md-3 control-label" for="semestre">Semestre</label>  
		  <div class="col-sm-3 col-md-2">
		  	<input id="semestre" name="semestre" type="text" value="<?php echo e($e->semestre); ?>" placeholder="Digite o semestre do evento" class="form-control input-md">
		  	<?php if(count($errors)>0): ?>
		  	 	<div class="text-danger">			
					<li style="list-style-type:none"><?php echo e($errors->first('semestre')); ?></li>
				</div>
			<?php endif; ?>	
		  </div>
		</div>

		<div class="form-group">
		  <label class="col-sm-4 col-md-3 control-label" for="tema">Tema</label>  
		  <div class="col-sm-8 col-md-6">
		  	<input id="tema" name="tema" type="text" value="<?php echo e($e->tema); ?>" placeholder="Digite o tema do evento" class="form-control input-md">
		  	<?php if(count($errors)>0): ?>
		  	 	<div class="text-danger">			
					<li style="list-style-type:none"><?php echo e($errors->first('tema')); ?></li>
				</div>
			<?php endif; ?>	
		  </div>
		</div>

		<div class="form-group">
		  <label class="col-sm-4 col-md-3  control-label" for="cidade">Cidade</label>  
		  <div class="col-sm-8 col-md-6">
		  	<input id="cidade" name="cidade" type="text" value="<?php echo e($e->cidade); ?>" placeholder="Digite a cidade do evento" class="form-control input-md">
		  	<?php if(count($errors)>0): ?>
		  	 	<div class="text-danger">			
					<li style="list-style-type:none"><?php echo e($errors->first('cidade')); ?></li>
				</div>
			<?php endif; ?>	
		  </div>
		</div>

		<div class="form-group">
		  <label class="col-sm-4 col-md-3 control-label" for="data_inicio">Data de Início</label>  
		  <div class="col-sm-4 col-md-3">
		  	<input id="data_inicio" name="data_inicio" type="date" value="<?php echo e($e->data_inicio); ?>" placeholder="Digite a data de ínicio do evento" class="form-control input-md">
		  	<?php if(count($errors)>0): ?>
		  	 	<div class="text-danger">			
					<li style="list-style-type:none"><?php echo e($errors->first('data_inicio')); ?></li>
				</div>
			<?php endif; ?>	
		  </div>
		</div>	

		<div class="form-group">
		  <label class="col-sm-4 col-md-3 control-label" for="data_fim">Data do Fim</label>  
		  <div class="col-sm-4 col-md-3">
		  	<input id="data_fim" name="data_fim" type="date" value="<?php echo e($e->data_fim); ?>" placeholder="Digite a data do fim do evento" class="form-control input-md">
		  	<?php if(count($errors)>0): ?>
		  	 	<div class="text-danger">			
					<li style="list-style-type:none"><?php echo e($errors->first('data_fim')); ?></li>
				</div>
			<?php endif; ?>	
		  </div>
		</div>

		<div class="form-group">
		  <div class="col-sm-offset-4 col-md-offset-3 col-sm-10">
		    <button class="btn btn-primary" type="submit">Editar</button>
		    <a href="/evento" class="btn btn-danger">Cancelar</a>
		  </div>
		</div>		

		</fieldset>
	</form>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>