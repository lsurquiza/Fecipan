<?php $__env->startSection('conteudo'); ?>
<div class="panel panel-default">
	<div class="panel-heading">
		<h4>Cadastro de Conteúdo Vinculado ao Perfil <?php echo e($perfil->descricao); ?></h4>
	</div>
	<div class="panel-body">
		<form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/permissao/create')); ?>">
			<?php echo e(csrf_field()); ?>

			
			<input type="hidden" name="perfil_id" value="<?php echo e($perfil->id); ?>">

			<div class="form-group<?php echo e($errors->has('rota') ? ' has-error' : ''); ?>">
				<label for="rota" class="col-sm-4 col-md-4 control-label">Rota</label>

				<div class="col-sm-4 col-md-6">
					<input id="rota" type="text" class="form-control" name="rota" value="<?php echo e(old('rota')); ?>" required autofocus>

					<?php if($errors->has('rota')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('rota')); ?></strong>
						</span>
					<?php endif; ?>
				</div>
			</div>

			<div class="form-group<?php echo e($errors->has('rotulo') ? ' has-error' : ''); ?>">
				<label for="rotulo" class="col-sm-4 col-md-4 control-label">Rótulo</label>

				<div class="col-sm-4 col-md-6">
					<input id="rotulo" type="text" class="form-control" name="rotulo" value="<?php echo e(old('rotulo')); ?>" required>

					<?php if($errors->has('rotulo')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('rotulo')); ?></strong>
						</span>
					<?php endif; ?>
				</div>
			</div>

			<div class="form-group<?php echo e($errors->has('publica') ? ' has-error' : ''); ?>">
				<label for="publica" class="col-sm-4 col-md-4 control-label">
					Visibilidade Pública
				</label>
				<div class="col-sm-4 col-md-6">
					<input type="checkbox" id="publica" name="publica" <?php echo e(old('publica')? "checked": ""); ?>>

					<?php if($errors->has('publica')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('publica')); ?></strong>
						</span>
					<?php endif; ?>
				</div>
			</div>

			<div class="form-group<?php echo e($errors->has('menu') ? ' has-error' : ''); ?>">
				<label for="menu" class="col-sm-4 col-md-4 control-label">
					Exibir no Menu
				</label>
				<div class="col-sm-4 col-md-6">
					<input type="checkbox" id="menu" name="menu" <?php echo e(old('menu')? "checked": ""); ?>>

					<?php if($errors->has('menu')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('menu')); ?></strong>
						</span>
					<?php endif; ?>
				</div>
			</div>
			
			<hr>
			<h4 class="col-sm-offset-2 col-md-offset-2">Permissões</h4>
			
			<div class="form-group<?php echo e($errors->has('visualizar') ? ' has-error' : ''); ?>">
				<label for="visualizar" class="col-sm-4 col-md-4 control-label">
					O usuário pode visualizar
				</label>	
				<div class="col-sm-4 col-md-6">
					<input type="checkbox" id="visualizar" name="visualizar" <?php echo e(old('visualizar')? "checked": ""); ?>>

					<?php if($errors->has('visualizar')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('visualizar')); ?></strong>
						</span>
					<?php endif; ?>
				</div>
			</div>

			<div class="form-group<?php echo e($errors->has('inserir') ? ' has-error' : ''); ?>">
				<label for="inserir" class="col-sm-4 col-md-4 control-label">
					O usuário pode inserir
				</label>
				<div class="col-sm-4 col-md-6">
					<input type="checkbox" id="inserir" name="inserir" <?php echo e(old('inserir')? "checked": ""); ?>>

					<?php if($errors->has('inserir')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('inserir')); ?></strong>
						</span>
					<?php endif; ?>
				</div>
			</div>

			<div class="form-group<?php echo e($errors->has('alterar') ? ' has-error' : ''); ?>">
				<label for="alterar" class="col-sm-4 col-md-4 control-label">
					O usuário pode alterar
				</label>
				<div class="col-sm-4 col-md-6">
					<input type="checkbox" id="alterar" name="alterar" <?php echo e(old('alterar')? "checked": ""); ?>>

					<?php if($errors->has('alterar')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('alterar')); ?></strong>
						</span>
					<?php endif; ?>
				</div>
			</div>

			<div class="form-group<?php echo e($errors->has('excluir') ? ' has-error' : ''); ?>">
				<label for="excluir" class="col-sm-4 col-md-4 control-label">
					O usuário pode excluir
				</label>
				<div class="col-sm-4 col-md-6">
					<input type="checkbox" id="excluir" name="excluir" <?php echo e(old('excluir')? "checked": ""); ?>>

					<?php if($errors->has('excluir')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('excluir')); ?></strong>
						</span>
					<?php endif; ?>
				</div>
			</div>

			<div class="form-group">
				<div class="col-md-6 col-sm-offset-4 col-md-offset-4">
					<button type="submit" class="btn btn-primary">
						Registrar
					</button>
					<a href="/perfil/permissoes/<?php echo e($perfil->id); ?>" class="btn btn-danger">
						Cancelar
					</a>
				</div>
			</div>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>