<!doctype html>
<html>
    <head>
        <title>SGCAE - Reserva e Alocação de Ambientes e Equipamentos</title>
        <meta charset="utf-8">
        
        <!-- Vincular com o arquivo css do Bootstrap -->
        <link rel="stylesheet" type="text/css" href="/css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="/css/theme.css">
        
        <!-- Vincular com os arquivos javascript do Bootstrap -->
        <script src="/js/jquery.js"></script>
        <script src="/js/bootstrap.js"></script>
    </head>
    
    <body>
        <nav class="navbar navbar-inverse navbar-fixed-top">
          <div class="container-fluid">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>                        
              </button>
              <a class="navbar-brand" href="/">
                <span class="glyphicon glyphicon-user"></span> Perfil
              </a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
              <ul class="nav navbar-nav">
                <li class="dropdown">
                  <a class="dropdown-toggle" data-toggle="dropdown" href="#">Administrador <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="/user">Usuários</a></li>
                    <li role="separator" class="divider"></li>
                    <li><a href="/servidor">Servidores</a></li>
                    <li><a href="/terceirizado">Terceirizados</a></li>
                  </ul>
                </li>
                <li><a href="/lotacao">Lotações</a></li>
                <li><a href="/equipamento">Equipamentos</a></li>
                <li><a href="/ambiente">Ambientes</a></li>
                <li><a href="/departamento">Departamentos</a></li>
                <li><a href="/reserva">Reserva</a></li>
              </ul>
              <ul class="nav navbar-nav navbar-right">
                <?php if(Auth::guest()): ?>
                <li><a href="/register"><span class="glyphicon glyphicon-user"></span> Cadastre-se</a></li>
                <li><a href="/login"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                <?php else: ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            <?php echo e(Auth::user()->nome); ?> <span class="caret"></span>
                        </a>

                        <ul class="dropdown-menu" role="menu">
                            <li>
                                <a href="<?php echo e(url('/logout')); ?>"
                                    onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                    Logout
                                </a>

                                <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
              </ul>
            </div>
          </div>
        </nav>
        <div class="container text-justify">
            <?php echo $__env->yieldContent('conteudo'); ?>

            <hr class="featurette-divider">
            
            <!-- FOOTER -->
            <footer>
                <p class="pull-right"><a href="#">Topo da Página</a></p>
                <p>Desenvolvido por <a href="mailto:acristn@hotmail.com">Ana Cristina Nunes</a></p>
            </footer>
        </div>
    </body>
</html>