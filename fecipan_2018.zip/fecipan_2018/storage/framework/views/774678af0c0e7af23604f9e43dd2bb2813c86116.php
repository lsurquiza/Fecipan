<!--esta visão irá aparecer dentro da principal.blade-->

<?php $__env->startSection('conteudo'); ?>

<h1>Usuários Cadastrados</h1>
<hr>
<table class="table table-condensed table-hover table-striped">
	<thead>
		<tr>
			<th>#</th>
			<th>Login</th>
			<th>Nome</th>
			<th>Perfil</th>
			<th>CPF</th>
			<th>Sexo</th>
			<th>Dt. Nascimento</th>
			<th>Email</th>
			<th>Ações</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($usuario->id); ?></td>
			<td><?php echo e($usuario->login); ?></td>
			<td><?php echo e($usuario->nome); ?></td>
			<td><?php echo e($usuario->perfil->descricao); ?></td>
			<td><?php echo e($usuario->cpf); ?></td>
			<td><?php echo e($usuario->sexo); ?></td>
			<td><?php echo e($usuario->data_de_nascimento); ?></td>
			<td><?php echo e($usuario->email); ?></td>
			<td>
				<div class="btn-group">
					<a href="\usuario\update\<?php echo e($usuario->id); ?>" class="btn btn-sm btn-primary" title="Alterar usuario">
						<span class="glyphicon glyphicon-edit"></span>
					</a>
					<?php if($usuario->perfil->administrador == 0): ?>
					<a href="#" data-toggle="modal" data-target="#delete_<?php echo e($usuario->id); ?>" class="btn btn-sm btn-primary" title="Excluir usuario">
						<span class="glyphicon glyphicon-trash"></span>
					</a>
					<?php endif; ?>
				</div>
				<?php if($usuario->perfil->administrador == 0): ?>
				<!-- Modal -->
				<div id="delete_<?php echo e($usuario->id); ?>" class="modal fade" role="dialog">
				  <div class="modal-dialog">

				    <!-- Modal content-->
				    <div class="modal-content">
				      <div class="modal-header">
				        <button type="button" class="close" data-dismiss="modal">&times;</button>
				        <h4 class="modal-title">
				        	<span class="glyphicon glyphicon-alert"></span>
				        	Exclusão de Usuário
				       	</h4>
				      </div>
				      <div class="modal-body">
				        <p>Confirma a exclusão do usuário <strong><?php echo e($usuario->id); ?> - <?php echo e($usuario->login); ?></strong>?</p>
				      </div>
				      <div class="modal-footer">
				        <a href="\usuario\delete\<?php echo e($usuario->id); ?>" class="btn btn-danger">Sim</a>
				        <button type="button" class="btn btn-info" data-dismiss="modal">Não</button>
				      </div>
				    </div>

				  </div>
				</div>
				<?php endif; ?>
			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</tbody>
</table>
<hr>
<a href="\usuario\create\1" class="btn btn-primary">
	<span class="glyphicon glyphicon-user"></span>
	Cadastrar Usuário
</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>