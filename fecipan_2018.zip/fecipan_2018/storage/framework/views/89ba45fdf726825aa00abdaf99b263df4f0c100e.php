<?php $__env->startSection('conteudo'); ?>

<?php if($permissoes->visualizar): ?>
	<div class="panel panel-default">
	  <div class="panel-heading">
		<h3>Questionário de Avaliação</h3>
		<h4>
			<strong>Trabalho:</strong>
			<?php echo e($avaliacao->trabalho->titulo); ?>

		</h4>
		<h4><strong>Código:</strong> <?php echo e($avaliacao->trabalho->cod); ?></h4>
		<h4><strong>Categoria:</strong> <?php echo e($avaliacao->trabalho->categoria->descricao); ?></h4>
		<h4><strong>Avaliador:</strong> <?php echo e($avaliacao->avaliador->pessoa->nome); ?></h4>
	  </div>
	  <div class="panel-body">
		<form class="form-horizontal" action="/avaliacao/notas" method="POST">
			<input class="hidden-print" type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
			<input class="hidden-print" type="hidden" name="avaliacao_id" value="<?php echo e($avaliacao->id); ?>" />
			  <div class="form-group">
				<?php $__currentLoopData = $avaliacao->trabalho->orientadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<div class="col-sm-offset-1 col-md-offset-1 col-sm-8 col-md-6">
					<b><?php echo e($o->pivot->tipo_orientacao == 1? "Orientador": "Coorientador"); ?>:</b> <?php echo e($o->pessoa->nome); ?><br>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				<?php $__currentLoopData = $avaliacao->trabalho->estudantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $es): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<div class="col-sm-offset-1 col-md-offset-1 col-sm-8 col-md-6">
					<b>Estudante:</b> <?php echo e($es->pessoa->nome); ?><br>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			  </div>
			  <?php $i = 1 ?>
			  <?php $__currentLoopData = $avaliacao->notas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			  <hr>
			  <div class="form-group text-left">
		  	 	<div class="col-sm-offset-1 col-sm-6 col-md-offset-2 col-md-5"> 
					<?php echo e($i++); ?> - <?php echo e($n->quesito->enunciado); ?> 
					<strong class='text-info'>(Peso <?php echo e($n->quesito->peso); ?>)</strong>
		  	 	</div>
		  	 	<div class="col-sm-3 col-md-3"> 
		  	 	 	<input name="notas[<?php echo e($n->id); ?>]" type="number" value="<?php echo e(is_null($n->valor)? "": $n->valor); ?>" min="0" max="10" step="0.1" class="form-control input-xs" placeholder="De 0.0 até 10.0" required>
		  	 	</div>
			  </div>
			  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			  
			  <div class="form-group">
				<div class="col-sm-offset-1 col-md-offset-2 col-sm-10">
				  <button class="btn btn-primary" type="submit">Registrar</button>
				  <a href="/trabalho/avaliacoes/<?php echo e($avaliacao->trabalho->id); ?>" class="btn btn-danger">Cancelar</a>
				</div>
			  </div>		
		</form>
	  </div>
	</div>
		<div class="text-center">
			<a href="javascript: window.print();" class="hidden-print btn btn-primary no-print" class="btn btn-primary"><span class="glyphicon glyphicon-print"></span> Imprimir</a>
		</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>