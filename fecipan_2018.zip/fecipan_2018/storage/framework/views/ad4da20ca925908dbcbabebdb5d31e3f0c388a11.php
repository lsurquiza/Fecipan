<?php $__env->startSection('conteudo'); ?>
<div class="panel panel-default">
	<div class="panel-heading">
		<h4>Cadastro de Usuário para <?php echo e($pessoa->nome); ?></h4>
	</div>
	<div class="panel-body">
		<form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/pessoa/usuario/create')); ?>">
			<?php echo e(csrf_field()); ?>

			<input type="hidden" name="pessoa_id" value="<?php echo e($pessoa->id); ?>">

			<?php if($perfis->count() == 1): ?>
			<input type="hidden" name="perfil_id" value="<?php echo e($perfis[0]->id); ?>">
			<?php else: ?>
			<div class="form-group<?php echo e($errors->has('perfil_id') ? ' has-error' : ''); ?>">
				<label for="perfil_id" class="col-sm-4 col-md-3 control-label">Perfil</label>

				<div class="col-sm-4 col-md-3">
					<select id="perfil_id" class="form-control" name="perfil_id">
						<option>Selecione...</option>
						<?php $__currentLoopData = $perfis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perfil): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<option value="<?php echo e($perfil->id); ?>" <?php echo e(old('perfil_id') == $perfil->id? 'selected': ''); ?>>
							<?php echo e($perfil->descricao); ?>

						</option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>                                    
					</select>

					<?php if($errors->has('perfil_id')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('perfil_id')); ?></strong>
						</span>
					<?php endif; ?>
				</div>
			</div>
			<?php endif; ?>

			<div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
				<label for="email" class="col-sm-4 col-md-3 control-label">E-Mail</label>

				<div class="col-sm-8 col-md-6">
					<input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')? old('email'): $pessoa->email); ?>" required>

					<?php if($errors->has('email')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('email')); ?></strong>
						</span>
					<?php endif; ?>
				</div>
			</div>

			<div class="form-group<?php echo e($errors->has('login') ? ' has-error' : ''); ?>">
				<label for="login" class="col-sm-4 col-md-3 control-label">Login</label>

				<div class="col-sm-6 col-md-4">
					<input id="login" type="text" class="form-control" name="login" value="<?php echo e(old('login')); ?>" required>

					<?php if($errors->has('login')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('login')); ?></strong>
						</span>
					<?php endif; ?>
				</div>
			</div>

			<div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
				<label for="password" class="col-sm-4 col-md-3 control-label">Senha</label>

				<div class="col-sm-6 col-md-4">
					<input id="password" type="password" class="form-control" name="password" required>

					<?php if($errors->has('password')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('password')); ?></strong>
						</span>
					<?php endif; ?>
				</div>
			</div>

			<div class="form-group">
				<label for="password-confirm" class="col-sm-4 col-md-3 control-label">Confirmar Senha</label>

				<div class="col-sm-6 col-md-4">
					<input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
				</div>
			</div>

			<div class="form-group">
				<div class="col-md-6 col-sm-offset-4 col-md-offset-3">
					<button type="submit" class="btn btn-primary">
						Registrar
					</button>
					<a href="\pessoa\usuarios\<?php echo e($pessoa->id); ?>" class="btn btn-danger">
						Cancelar
					</a>
				</div>
			</div>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>