<?php $__env->startSection('conteudo'); ?>
<div class="row">
	<div class="col-sm-offset-2 col-sm-8 col-sm-offset-2">
	<h3 style="text-align:center">Cadastro de Tipo de Trabalho</h3>
	<hr>
	<form class="form-horizontal" action="/tipoTrabalho/create" method="POST">
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
		<fieldset>

		<div class="form-group">
		  <label for="nome">Nome</label>  
		  <div>
		  	<input id="nome" name="nome" type="text" placeholder="Digite o tipo de trabalho" class="form-control input-md">
		  	<?php if(count($errors)>0): ?>
		  	 	<div class="alert alert-danger">			
					<h4><?php echo e($errors->first('nome')); ?></h4>
				</div>
			<?php endif; ?>	
		  </div>
		</div>

		<div class="form-group">
		  <label class="col-md-5 control-label" for="submit"></label>
		  <div >
		    <button class="btn btn-primary" type="submit">Registrar</button>
		    <a href="/tipoTrabalho" class="btn btn-danger">Cancelar</a>
		  </div>
		</div>		

		</fieldset>
	</form>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>